package com.cg.payroll.client;

import java.util.Scanner;

import oracle.jdbc.driver.OracleDriver;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.daoservices.AssociateDAOImpl;
import com.cg.payroll.exceptions.AssociateDetailNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
public class MainClass {

	public static void main(String[] args) {
		PayrollServices payrollServices = new PayrollServicesImpl();
		Scanner sc = new Scanner(System.in);
		int option = sc.nextInt();
		System.out.println("Choose from 1,2, 3, 4");
		PayrollServices payrollServices1 = new PayrollServicesImpl();
		String userChoice="y";
		while(userChoice.compareToIgnoreCase("y")==0){
//			System.out.println("Payroll Services!\n1. Add Associate Details\n2. Get Total Salary of the Associate\n3. Retrieve the details of a specific Associate\n4. Retrieve all Associates details\nEnter your choice:");
			switch(option){
			case 1:
				try {
					//				System.out.println("enter the number of associates: ");int n = sc.nextInt();
					//				for(int i = 0;i<=n; i++){
					System.out.println("Enter yearlyinvestment: ");int y = sc.nextInt();
					System.out.println("Enter firstname: ");String f = sc.next();
					System.out.println("Enter lastname: ");String l = sc.next();
					System.out.println("Enter designation: ");String d = sc.next();
					System.out.println("Enter department: ");String m = sc.next();
					System.out.println("Enter pancard: ");String p = sc.next();
					System.out.println("Enter emailid: ");String e = sc.next();
					System.out.println("Enter basicsalary: ");int b = sc.nextInt();
					System.out.println("Enter epf: ");int ep = sc.nextInt();
					System.out.println("Enter comapnypf: ");int cp = sc.nextInt();
					System.out.println("Enter accountno: ");int an = sc.nextInt();
					System.out.println("Enter bankname: ");String bn = sc.next();
					System.out.println("Enter ifsc: ");String ifsc = sc.next();
					System.out.println(payrollServices1.acceptAssociateDetails(f, l, e,m, d, p,y, b, ep, cp, an, bn, ifsc)+"Added Successfully");
					//			}
				} catch (PayrollServicesDownException e) { e.printStackTrace(); }
				break;

			case 2:
				System.out.println("Enter the associateId whose details need to be found");
				int associateId = sc.nextInt();
				System.out.println("Associate Details are: "+ payrollServices1.getAssociateDetails(associateId));
				break;

			case 3:
				System.out.println("Enter the associateId whose net salary needs to be found");
				int associateId1 = sc.nextInt();
				System.out.println("Net Salary: "+ payrollServices1.calculateNetSalary(associateId1));
				break;

			case 4:
				try {
					for (Associate a: payrollServices1.getAllAssociateDetails())
						System.out.println(a.toString());
				} catch (PayrollServicesDownException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			}
			System.out.println("\nDo you wanna continue(y/n):");
			userChoice = sc.next();
		}
		sc.close();
	}
	//System.out.println(Associate.getASSOCIATE_COUNTER());
	/*int num = 100;
			/*Associate associate1 = new Associate(101, 15000,"Shraddha","Singh", "Sr.Con","YTP","JDDU2664","shraddha@gmail.com");
			Associate associate2 = new Associate(102, 15000,"Arpita","Singh", "Sr.Con","YTP","UIDIDI737","arpita@gmail.com");
			BankDetails bankDetail1 = new BankDetails(1010, "HDFC", "HDFC0007");
			BankDetails bankDetail2 = new BankDetails(1020, "ICICI", "ICIC007");
			Salary salary1 =  new Salary(50000, 3000, 1000, 1500, 2500, 1500, 500, 1200, 5200, 2500000,200000);
			Salary salary2 =  new Salary(40000, 2000, 1500, 1200, 2500, 1500, 500, 1300, 5200, 2300000,180000);*/
	/*	Associate associate = new Associate(101, 15000, "Shraddha", "Singh", "ADM", "Sr.Analyst", "sd5654", "shraddha@gmail.com",
					new Salary(35000, 1000, 1000, 2000), new BankDetails(1111, "HDFC", "HDFC0023"));

			associate.getSalary().setHra((30*associate.getSalary().getBasicSalary()/100));
			associate.getSalary().setOtherAllowance((20*associate.getSalary().getBasicSalary()/100));
			associate.getSalary().setPersonalAllowance((25*associate.getSalary().getBasicSalary()/100));
			associate.getSalary().setConveyenceAllowance((10*associate.getSalary().getBasicSalary()/100));
			associate.getSalary().setGrossSalary((associate.getSalary().getBasicSalary()+associate.getSalary().getHra()
					+associate.getSalary().getPersonalAllowance()+associate.getSalary().getOtherAllowance()+associate.getSalary().getConveyenceAllowance()));
	 */
	//		PayrollServices payrollServices = new PayrollServicesImpl();
	//		payrollServices.acceptAssociateDetails("Shraddha", "Singh", "shraddha@gmail.com", "YTP", "Sr.Con", "JDDU2664",15000, 50000, 3000, 1000, 1111, "HDFC", "HDFC0023");
	//		payrollServices.acceptAssociateDetails("Arpita", "Singh", "shraddha@gmail.com", "YTP", "Sr.Con", "JDDU2664",15000, 50000, 3000, 1000, 1111, "HDFC", "HDFC0023");
	//		System.out.println(payrollServices.calculateNetSalary(101));
	//		System.out.println(payrollServices.getAssociateDetails(101));
	//		
}

