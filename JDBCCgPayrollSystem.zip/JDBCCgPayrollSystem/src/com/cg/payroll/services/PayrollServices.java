package com.cg.payroll.services;

import java.util.ArrayList;
import java.util.HashMap;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;

public interface PayrollServices {
	int acceptAssociateDetails(String firstname, String lastName, String emailId, String department, 
			String designation, String pancard, int yearlyInvestmentUnder80C, int basicsalary, int epf, 
			int companyPf, int accountNumber, String bankName, String ifscCode)throws PayrollServicesDownException;
	
	int calculateNetSalary(int associateId);
	
	Associate getAssociateDetails(int associateId);
	
//	ArrayList<Associate> getAllAssociateDetails();
	public ArrayList<Associate> getAllAssociateDetails()throws PayrollServicesDownException;
	
}
